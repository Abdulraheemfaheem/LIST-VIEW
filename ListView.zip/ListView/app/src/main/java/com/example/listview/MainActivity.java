package com.example.listview;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import com.example.listview.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private EditText editTextName;
    private EditText editTextSearch;
    private Button buttonSave;
    private Button buttonSearch;
    private Button buttonUpdate;
    private Button buttonDelete;
    private ListView listViewNames;

    private ArrayList<String> names;
    private ArrayAdapter<String> adapter;
    private int selectedPosition = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextName = findViewById(R.id.edit_text_name);
        editTextSearch = findViewById(R.id.edit_text_search);
        buttonSave = findViewById(R.id.button_save);
        buttonSearch = findViewById(R.id.button_search);
        buttonUpdate = findViewById(R.id.button_update);
        buttonDelete = findViewById(R.id.button_delete);
        listViewNames = findViewById(R.id.list_view_names);

        names = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, names);
        listViewNames.setAdapter(adapter);

        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = editTextName.getText().toString();
                if (!name.isEmpty()) {
                    names.add(name);
                    adapter.notifyDataSetChanged();
                    editTextName.setText("");
                }
            }
        });

        buttonSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String searchTerm = editTextSearch.getText().toString().toLowerCase();
                ArrayList<String> filteredNames = new ArrayList<>();

                for (String name : names) {
                    if (name.toLowerCase().contains(searchTerm)) {
                        filteredNames.add(name);
                    }
                }

                adapter = new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_list_item_1, filteredNames);
                listViewNames.setAdapter(adapter);
            }
        });

        listViewNames.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                selectedPosition = position;
                editTextName.setText(names.get(position));
            }
        });

        buttonUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selectedPosition != -1) {
                    names.set(selectedPosition, editTextName.getText().toString());
                    adapter.notifyDataSetChanged();
                    editTextName.setText("");
                    selectedPosition = -1;
                }
            }
        });

        buttonDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selectedPosition != -1) {
                    names.remove(selectedPosition);
                    adapter.notifyDataSetChanged();
                    editTextName.setText("");
                    selectedPosition = -1;
                }
            }
        });
    }
}